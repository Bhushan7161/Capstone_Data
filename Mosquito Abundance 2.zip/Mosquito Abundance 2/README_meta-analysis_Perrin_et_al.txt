

METHODOLOGICAL INFORMATION

Peer-reviewed publications were sourced from the following databases: Web of Science Core Collection, KCI-Korean Journal Database, MEDLINE, Russian Science Citation Index and SciELO Citation Index (http://www.webofknowledge.com) using a combination of key words including Culicidae, presence, abundance, richness, diversity, habitat loss, fragmentation, anthropogenic, landscape/land-use change, urban, agriculture and forest. The search generated 1648 studies published until June 2021.
We first eliminated the references that did not fit the purpose of our review based on their title and abstract. Then, we excluded studies whose objectives were not to test the effect of landscape anthropization on mosquito abundance and diversity after a full reading of the text. This resulted in 107 studies from which data were extracted. The process and outcome of the literature search can be accessed through the associated article.
We tested the overall effect of landscape anthropization on mosquito presence/abundance and diversity using a random-effects and multilevel models to estimate the mean of the distribution of effect sizes. Then, we ran a meta-regression to assess the contribution of the ‘mosquito’s ability to transmit human pathogens’ moderator to the heterogeneity of effect sizes.

DATA-SPECIFIC INFORMATION FOR: data_meta-analysis_Perrin_et_al.csv

1. Number of variables
16.

2. Number of rows
339.

3. Variable List 
es.id: label of each effect size (1 to 338).

publication_number: label of each study included in the meta-analysis.

year: year of the publication of the study.

geographic_continent, geographic_country, latitude and longitude: Location of the study.

response_var: studied response (mosquito presence, abundance or diversity).

mosquito_species and mosquito_genus: scientific name of the mosquito species studied.

life_stage: mosquito life stage studied (adult, immature or both).
	
n: number of observations.

r: Pearson correlation coefficient between landscape anthropization variable and the response_var.
	
z and var_z: Fisher’s z and its variance – Effect size used in the meta-analysis.
	
vector_status: class of associated VBD numbers (A = 0, B = 1 to 3, C = 4 to 6, D = 7 to 9, and E = 10 or more associated VBDs).

4. Missing data codes: 
Labeled ‘NA’.

DATA-SPECIFIC INFORMATION FOR: R_script_meta-analysis_Perrin_et_al.R

Each analysis step is detailed within the code.
